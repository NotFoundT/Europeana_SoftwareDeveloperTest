/* 
 * CalculateSmallestNo Project determines the smallest positive number that can be divided by a sequential range of numbers (from 1 to 25)
 * 
 * CalculateSmallestNo is developed using : SpringBoot, Maven , Java 8.
 * 
 * Tools required to build and execute the application : Spring tool suite(sts-3.9.8.RELEASE) and PostMan
 *
 * There are two Rest End Points 
 * 
 * 1. localhost:8080/settheupperlimit/{upperlimit} :: which will set the upper range for calculation and will check that value doesn't exceed 25.
 * 
 * 2. localhost:8080/calcsmallestnumber :: will give the result in two formats XML and JSON depending upon the Accept Http request headers.
 * 
 * 
 */