package com.calculate.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.calculate.constants.Constants;
import com.calculate.model.Range;
import com.calculate.service.CalcSmallestNoServiceImp;

public class TestCalculateSmallestNo {
	
	public static Logger logger = LoggerFactory.getLogger(TestCalculateSmallestNo.class);

	CalcSmallestNoServiceImp calcService= new CalcSmallestNoServiceImp();
	Range range= new Range();

	
	@Test
	public void smallestnumber1_10() {
       logger.info("EXECUTING TEST1 : RESULT OF SMALLEST NUMBER FOR RANGE 1 TO 10");
	   calcService.setTheUpperLimit(10);
       assertEquals(2520, calcService.calcSmallestNumber().getSmallestNumber());
	}

	@Test
	public void smallestnumber1_15() {
       logger.info("EXECUTING TEST2 : RESULT OF SMALLEST NUMBER FOR RANGE 1 TO 15");
	   calcService.setTheUpperLimit(15);
       assertEquals(360360, calcService.calcSmallestNumber().getSmallestNumber());
       
	}
	
	@Test
	public void upperRangeCheckSuccess() {
       logger.info("EXECUTING TEST3 : UPPER RANGE Success CHECK");
	   
       assertEquals(Constants.SUCCESS_STATUS, calcService.setTheUpperLimit(10).getStatus());
       assertEquals(Constants.SUCCESS_STATUS, calcService.setTheUpperLimit(15).getStatus());
       assertEquals(Constants.SUCCESS_STATUS, calcService.setTheUpperLimit(20).getStatus());
       assertEquals(Constants.SUCCESS_STATUS, calcService.setTheUpperLimit(25).getStatus());

       
	}
	
	
	@Test
	public void upperRangeCheckFailure() {
       logger.info("EXECUTING TEST4 : UPPER RANGE FAILURE CHECK");
	   
       assertEquals(0, calcService.setTheUpperLimit(26).getUpperRange());
       assertEquals(Constants.FAILURE_STATUS, calcService.setTheUpperLimit(26).getStatus());
       assertEquals(Constants.FAILURE_MESSAGE, calcService.setTheUpperLimit(26).getMessage());
         
	}

	
	@Test
	public void testCalculateAPISuccess() throws URISyntaxException
	{
	       logger.info("EXECUTING TEST6 : TESTING API");

	    RestTemplate restTemplate = new RestTemplate();
	    
	    final String baseUrl = "http://localhost:8080"+"/calcsmallestnumber";
	    URI uri = new URI(baseUrl);
	    
	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	     
	    //Verify request succeed
	    assertEquals(200, result.getStatusCodeValue());
	    assertEquals(true, result.getBody().contains("smallestNumber"));

	}

	
}
