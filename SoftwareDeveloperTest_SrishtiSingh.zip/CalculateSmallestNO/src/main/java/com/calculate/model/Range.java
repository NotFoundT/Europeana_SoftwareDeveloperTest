package com.calculate.model;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Repository;

@XmlRootElement
@Repository
public class Range {

	
	private long upperRange;
	private String status;
	private String message;
	
	public Range() {
		super();
	}

	
	public Range(long upperRange, String status, String message) {
		super();
		this.upperRange = upperRange;
		this.status = status;
		this.message = message;
	}


	public long getUpperRange() {
		return upperRange;
	}

	public void setUpperRange(long upperRange) {
		this.upperRange = upperRange;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	
}
