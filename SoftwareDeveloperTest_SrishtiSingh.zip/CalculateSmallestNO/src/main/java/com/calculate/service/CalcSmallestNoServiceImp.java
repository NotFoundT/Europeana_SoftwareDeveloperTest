package com.calculate.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calculate.constants.Constants;
import com.calculate.model.Range;
import com.calculate.model.SmallestNumber;

@Service
public class CalcSmallestNoServiceImp implements CalcSmallestNoService {

	private static final Logger logger = LoggerFactory.getLogger(CalcSmallestNoServiceImp.class);
	@Autowired 
	SmallestNumber result;
	@Autowired
	Range range;
	
	//method to set the upper limit
	@Override
	public Range setTheUpperLimit(long upperLimit) {
		logger.info("INSIDE THE METHOD setTheUpperLimit");
		logger.info("VALUE PASSED FOR UPPERLIMIT :: " + upperLimit);
        if(upperLimit>Constants.UPPER_LIMIT_CHECK)
        {
        	range.setStatus(Constants.FAILURE_STATUS);
        	range.setUpperRange(0);
        	range.setMessage(Constants.FAILURE_MESSAGE);
        }
        else
        {
        	range.setStatus(Constants.SUCCESS_STATUS);
        	range.setUpperRange(upperLimit);
        	range.setMessage(Constants.SUCCESS_MESSAGE);
         }
		
		logger.info("OUT OF METHOD  setTheUpperLimit");

		return range;
	}

	
	
	//method to get the result
	@Override
	public SmallestNumber calcSmallestNumber() {
		logger.info("INSIDE THE METHOD calcSmallestNumber");

		if (range.getUpperRange() == 0 || range.getStatus().equals(Constants.FAILURE_STATUS)) {
			logger.info("NO VALUE IS SET FOR UPPER LIMIT");
			logger.info("CALCULATION WILL BE DONE ONLY FOR 1");
			range.setUpperRange(1);
		}
		logger.info("RANGE :: 1-" + range.getUpperRange());

		long start = System.nanoTime();

		logger.info("STARTING THE CALCULATION :: START TIME :: " + start);

		long smallestNumber = lcm(range.getUpperRange());
		long finish = System.nanoTime();

		logger.info("CALCULATION ENDS :: END TIME :: " + finish);
		logger.info("CALCULATION TIME IN NANOSECONDS :: " + (finish - start));
		double timeInCalculation = (finish - start)/1000000.0;

		logger.info("SMALLEST NUMBER CALCULATED IN TIME  :: " + timeInCalculation + " milliseconds is :: " + smallestNumber);

		result.setSmallestNumber(smallestNumber);
		result.setTimeInCalculating(timeInCalculation);

		logger.info("OUT OF METHOD  calcSmallestNumber");

		return result;
	}

	
	//method to calculate GCD
	public static long gcd(long a, long b) {
		logger.info("INSIDE THE METHOD gcd");

		if (a % b != 0) return gcd(b, a % b);
		else logger.info("OUT OF METHOD");
		return b;
	}

	
	//method to calculate LCM
	public static long lcm(long upperLimit) {
		logger.info("INSIDE THE METHOD lcm");

		long ans = 1;
		for (long i = 1; i <= upperLimit; i++)
		ans = (ans * i) / (gcd(ans, i));

		logger.info("OUT OF METHOD lcm");

		return ans;
	}
}