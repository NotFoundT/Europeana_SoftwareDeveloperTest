package com.calculate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.calculate.model.Range;
import com.calculate.model.SmallestNumber;
import com.calculate.service.CalcSmallestNoServiceImp;

@RestController
public class CalcSmallestNoController {

	@Autowired
	private CalcSmallestNoServiceImp smallestNoService;

	@RequestMapping(value = "/settheupperlimit/{upperlimit}",  produces = {
			MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE})
	public Range setTheUpperLimit(@PathVariable(value = "upperlimit") String upperlimit) {
		return smallestNoService.setTheUpperLimit(Long.parseLong(upperlimit));
	}

	
	@RequestMapping(value = "/calcsmallestnumber", produces = {
		MediaType.APPLICATION_XML_VALUE,
		MediaType.APPLICATION_JSON_VALUE
	},
	consumes = MediaType.ALL_VALUE)
	public SmallestNumber calcSmallestNumber() {
		
		return smallestNoService.calcSmallestNumber();

	}

}